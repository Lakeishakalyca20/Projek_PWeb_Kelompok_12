<?php
include 'koneksi.php';
cek_login();
include 'kartu.php';

$top = ambil_catatan($db, "c.status='publish'", "rata DESC, jml DESC, c.created_at DESC", 6);

include 'header.php';
?>

<h2>Halo <?= e($_SESSION['nama']) ?>! Yuk upload cttn mu!</h2>

<form action="cari.php" class="cari">
    <input name="q" placeholder="Search...">
    <button>Cari</button>
</form>

<h3>Ruang populer (rating tertinggi)</h3>

<div class="grid">
    <?php while ($r = $top->fetch_assoc()): ?>
        <?php kartu($r, $db); ?>
    <?php endwhile; ?>
</div>

<?php if ($top->num_rows == 0): ?>
    <p>Belum ada catatan. <a href="upload.php">Upload yang pertama!</a></p>
<?php endif; ?>

<?php include 'footer.php'; ?>
