<?php
include 'koneksi.php';
cek_login();

$id = (int)($_GET['id'] ?? 0);
$uid = $_SESSION['uid'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simpan rating
    if (isset($_POST['nilai'])) {
        $n = max(1, min(5, (int)$_POST['nilai']));

        $st = $db->prepare(
            "INSERT INTO rating(catatan_id,user_id,nilai) VALUES(?,?,?)
             ON DUPLICATE KEY UPDATE nilai=?"
        );
        $st->bind_param("iiii", $id, $uid, $n, $n);
        $st->execute();
    }

    // Simpan komentar / balasan
    if (isset($_POST['isi']) && trim($_POST['isi']) !== '') {
        $p = (int)($_POST['parent'] ?? 0) ?: null;
        $isi = trim($_POST['isi']);

        $st = $db->prepare("INSERT INTO komentar(catatan_id,user_id,parent_id,isi) VALUES(?,?,?,?)");
        $st->bind_param("iiis", $id, $uid, $p, $isi);
        $st->execute();
    }

    header("Location: catatan.php?id=$id");
    exit;
}

$c = ambil_catatan($db, "c.id=?", "c.id", 1, "i", [$id])->fetch_assoc();

if (!$c || ($c['status'] == 'draft' && $c['user_id'] != $uid)) {
    http_response_code(404);
    die("Catatan tidak ditemukan.");
}

$ext = strtolower(pathinfo($c['file'], PATHINFO_EXTENSION));

$ks = $db->prepare(
    "SELECT k.*, u.nama
     FROM komentar k JOIN users u ON u.id=k.user_id
     WHERE catatan_id=? ORDER BY k.created_at"
);
$ks->bind_param("i", $id);
$ks->execute();
$semua = $ks->get_result()->fetch_all(MYSQLI_ASSOC);

include 'header.php';
?>

<h2><?= e($c['judul']) ?></h2>

<p class="meta">
    oleh <a href="profil.php?id=<?= $c['user_id'] ?>"><?= e($c['nama']) ?></a>
    · <?= e($c['mata_kuliah']) ?>
    · Angkatan <?= e($c['angkatan']) ?>
    · ★ <?= number_format($c['rata'], 1) ?> (<?= $c['jml'] ?> penilaian)
    · Tag: <?= e($c['tag']) ?>
</p>

<div class="detail">

    <!-- Pratinjau catatan -->
    <div class="box">
        <?php if ($ext == 'pdf'): ?>
            <iframe class="prev" src="uploads/<?= e($c['file']) ?>"></iframe>
        <?php elseif (in_array($ext, ['jpg', 'jpeg', 'png'])): ?>
            <div class="prev" style="height:auto">
                <img src="uploads/<?= e($c['file']) ?>" alt="">
            </div>
        <?php else: ?>
            <p>Pratinjau tidak tersedia untuk file .<?= e($ext) ?>.</p>
        <?php endif; ?>

        <p><?= nl2br(e($c['deskripsi'])) ?></p>

        <a class="btn" href="uploads/<?= e($c['file']) ?>" download>Unduh</a>
        <a class="btn alt" href="bookmark.php?id=<?= $id ?>&kembali=<?= urlencode("catatan.php?id=$id") ?>">♥ Simpan</a>

        <form method="post" style="margin-top:14px">
            Beri rating:
            <select name="nilai" style="width:auto">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <option value="<?= $i ?>"><?= $i ?> ★</option>
                <?php endfor; ?>
            </select>
            <button>Kirim</button>
        </form>
    </div>

    <!-- Forum diskusi -->
    <div class="box">
        <h3>Forum Diskusi</h3>

        <form method="post">
            <textarea name="isi" rows="2" placeholder="Tulis pertanyaan..." required></textarea>
            <button>Kirim</button>
        </form>

        <?php foreach ($semua as $k): ?>
            <?php if (!$k['parent_id']): ?>
                <div class="komen">
                    <b><?= e($k['nama']) ?></b><br>
                    <?= nl2br(e($k['isi'])) ?>

                    <?php foreach ($semua as $b): ?>
                        <?php if ($b['parent_id'] == $k['id']): ?>
                            <div class="komen balas">
                                <b><?= e($b['nama']) ?></b><br>
                                <?= nl2br(e($b['isi'])) ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>

                    <details>
                        <summary>Balas</summary>
                        <form method="post">
                            <input type="hidden" name="parent" value="<?= $k['id'] ?>">
                            <textarea name="isi" rows="2" required></textarea>
                            <button>Kirim</button>
                        </form>
                    </details>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

</div>

<?php include 'footer.php'; ?>
