</main>

<footer>NoteShare · Kelompok 12 · Pendidikan Teknik Informatika</footer>

</body>
</html>
