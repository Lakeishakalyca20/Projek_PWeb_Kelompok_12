<?php
include 'koneksi.php';
cek_login();
include 'kartu.php';

$id = (int)($_GET['id'] ?? $_SESSION['uid']);

$st = $db->prepare("SELECT * FROM users WHERE id=?");
$st->bind_param("i", $id);
$st->execute();
$u = $st->get_result()->fetch_assoc();

if (!$u) {
    die("Pengguna tidak ditemukan.");
}

$data = ambil_catatan($db, "c.user_id=? AND c.status='publish'", "c.created_at DESC", 30, "i", [$id]);

include 'header.php';
?>

<h2>Catatan yang dipublish <?= e($u['nama']) ?></h2>

<div class="dua">

    <div class="grid">
        <?php while ($r = $data->fetch_assoc()): ?>
            <?php kartu($r, $db); ?>
        <?php endwhile; ?>
    </div>

    <div class="box" style="text-align:center">
        <div class="avatar">👤</div>
        <h3><?= e($u['nama']) ?></h3>
        <p>
            <?= e($u['univ']) ?><br>
            NIM: <?= e($u['nim']) ?>
        </p>

        <?php if ($u['link_ig']): ?>
            <p><a href="<?= e($u['link_ig']) ?>" target="_blank" rel="noopener">Instagram</a></p>
        <?php endif; ?>

        <?php if ($u['link_linkedin']): ?>
            <p><a href="<?= e($u['link_linkedin']) ?>" target="_blank" rel="noopener">LinkedIn</a></p>
        <?php endif; ?>

        <p><?= nl2br(e($u['bio'])) ?></p>

        <?php if ($id == $_SESSION['uid']): ?>
            <a class="btn" href="profil_edit.php">Ubah</a>
        <?php endif; ?>
    </div>

</div>

<?php include 'footer.php'; ?>
