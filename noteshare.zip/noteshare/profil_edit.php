<?php
include 'koneksi.php';
cek_login();

$uid = $_SESSION['uid'];
$ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ig = $_POST['link_ig'];
    $li = $_POST['link_linkedin'];

    // Link hanya diterima kalau diawali http:// atau https://
    if ($ig !== '' && !preg_match('#^https?://#i', $ig)) {
        $ig = '';
    }

    if ($li !== '' && !preg_match('#^https?://#i', $li)) {
        $li = '';
    }

    $st = $db->prepare(
        "UPDATE users
         SET nama=?, univ=?, nim=?, link_ig=?, link_linkedin=?, bio=?
         WHERE id=?"
    );
    $st->bind_param(
        "ssssssi",
        $_POST['nama'],
        $_POST['univ'],
        $_POST['nim'],
        $ig,
        $li,
        $_POST['bio'],
        $uid
    );
    $st->execute();

    $_SESSION['nama'] = $_POST['nama'];
    $ok = "Profil diperbarui (link harus diawali http/https).";
}

$st = $db->prepare("SELECT * FROM users WHERE id=?");
$st->bind_param("i", $uid);
$st->execute();
$u = $st->get_result()->fetch_assoc();

include 'header.php';
?>

<h2>Profil Saya</h2>

<?php if ($ok): ?>
    <div class="alert ok"><?= e($ok) ?></div>
<?php endif; ?>

<form method="post" class="box">
    <label>Nama</label>
    <input name="nama" value="<?= e($u['nama']) ?>" required>

    <label>Universitas</label>
    <input name="univ" value="<?= e($u['univ']) ?>">

    <label>NIM</label>
    <input name="nim" value="<?= e($u['nim']) ?>">

    <label>Email</label>
    <input value="<?= e($u['email']) ?>" disabled>

    <label>Link Instagram</label>
    <input name="link_ig" value="<?= e($u['link_ig']) ?>" placeholder="https://instagram.com/...">

    <label>Link LinkedIn</label>
    <input name="link_linkedin" value="<?= e($u['link_linkedin']) ?>" placeholder="https://linkedin.com/in/...">

    <label>Bio</label>
    <textarea name="bio" rows="3"><?= e($u['bio']) ?></textarea>

    <button>Simpan</button>
</form>

<?php include 'footer.php'; ?>
