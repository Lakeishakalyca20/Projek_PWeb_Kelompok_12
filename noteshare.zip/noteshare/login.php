<?php
include 'koneksi.php';

$tanpa_menu = 1;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $st = $db->prepare("SELECT id,nama,password FROM users WHERE email=?");
    $st->bind_param("s", $_POST['email']);
    $st->execute();
    $u = $st->get_result()->fetch_assoc();

    if ($u && password_verify($_POST['password'], $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['uid'] = $u['id'];
        $_SESSION['nama'] = $u['nama'];
        header("Location: index.php");
        exit;
    }

    $err = "Email atau password salah.";
}

include 'header.php';
?>

<div class="auth">
    <div style="font-size:48px">📒</div>
    <h2>Login NoteShare</h2>

    <div class="box">
        <?php if (isset($_GET['daftar'])): ?>
            <div class="alert ok">Berhasil daftar, silakan login.</div>
        <?php endif; ?>

        <?php if ($err): ?>
            <div class="alert"><?= e($err) ?></div>
        <?php endif; ?>

        <form method="post">
            <input type="email" name="email" placeholder="Email" required>
            <br><br>
            <input type="password" name="password" placeholder="Password" required>
            <button>Login</button>
        </form>
    </div>

    <p>Belum punya akun? <a href="register.php">Regist</a></p>
</div>

<?php include 'footer.php'; ?>
