<?php
include 'koneksi.php';
cek_login();
include 'kartu.php';

$q = trim($_GET['q'] ?? '');
$l = "%$q%";

$hasil = ambil_catatan(
    $db,
    "c.status='publish' AND (c.judul LIKE ? OR c.mata_kuliah LIKE ? OR c.tag LIKE ?)",
    "rata DESC",
    12,
    "sss",
    [$l, $l, $l]
);

$baru = ambil_catatan($db, "c.status='publish'", "c.created_at DESC", 6);

include 'header.php';
?>

<form class="cari">
    <input name="q" value="<?= e($q) ?>" placeholder="Cari judul, mata kuliah, tag...">
    <button>Cari</button>
</form>

<h3>Rating tertinggi<?= $q ? " untuk \"" . e($q) . "\"" : "" ?></h3>

<div class="grid">
    <?php while ($r = $hasil->fetch_assoc()): ?>
        <?php kartu($r, $db); ?>
    <?php endwhile; ?>
</div>

<?php if ($hasil->num_rows == 0): ?>
    <p>Tidak ada hasil.</p>
<?php endif; ?>

<h3>Catatan terbaru</h3>

<div class="grid">
    <?php while ($r = $baru->fetch_assoc()): ?>
        <?php kartu($r, $db); ?>
    <?php endwhile; ?>
</div>

<?php include 'footer.php'; ?>
