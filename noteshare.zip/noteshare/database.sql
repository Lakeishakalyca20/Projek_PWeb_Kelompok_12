CREATE DATABASE IF NOT EXISTS noteshare CHARACTER SET utf8mb4;
USE noteshare;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    univ VARCHAR(100),
    nim VARCHAR(30),
    link_ig VARCHAR(150),
    link_linkedin VARCHAR(150),
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE catatan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    judul VARCHAR(150) NOT NULL,
    mata_kuliah VARCHAR(100) NOT NULL,
    angkatan VARCHAR(10),
    tag VARCHAR(150),
    deskripsi TEXT,
    file VARCHAR(255) NOT NULL,
    status ENUM('publish', 'draft') DEFAULT 'publish',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE rating (
    id INT AUTO_INCREMENT PRIMARY KEY,
    catatan_id INT NOT NULL,
    user_id INT NOT NULL,
    nilai TINYINT NOT NULL,
    UNIQUE (catatan_id, user_id),
    FOREIGN KEY (catatan_id) REFERENCES catatan(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE bookmark (
    user_id INT NOT NULL,
    catatan_id INT NOT NULL,
    PRIMARY KEY (user_id, catatan_id),
    FOREIGN KEY (catatan_id) REFERENCES catatan(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE komentar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    catatan_id INT NOT NULL,
    user_id INT NOT NULL,
    parent_id INT NULL,
    isi TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (catatan_id) REFERENCES catatan(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
