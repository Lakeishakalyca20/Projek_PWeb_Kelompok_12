<?php
session_start();

$db = new mysqli("127.0.0.1", "root", "", "noteshare", 3308);

if ($db->connect_error) {
    die("Koneksi gagal");
}

$db->set_charset("utf8mb4");

function e($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function cek_login()
{
    if (!isset($_SESSION['uid'])) {
        header("Location: login.php");
        exit;
    }
}

// Ambil catatan + rata-rata rating. $where & $order hanya string internal (bukan input user).
function ambil_catatan(
    $db,
    $where = "c.status='publish'",
    $order = "rata DESC, c.created_at DESC",
    $limit = 6,
    $types = "",
    $params = []
) {
    $sql = "SELECT c.*, u.nama, COALESCE(AVG(r.nilai),0) rata, COUNT(r.id) jml
            FROM catatan c JOIN users u ON u.id=c.user_id
            LEFT JOIN rating r ON r.catatan_id=c.id
            WHERE $where GROUP BY c.id ORDER BY $order LIMIT " . (int)$limit;

    $st = $db->prepare($sql);

    if ($params) {
        $st->bind_param($types, ...$params);
    }

    $st->execute();
    return $st->get_result();
}
