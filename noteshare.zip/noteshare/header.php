<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NoteShare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php if (!isset($tanpa_menu)): ?>
    <header class="top">
        <a href="javascript:history.back()" class="back">←</a>
        <a href="index.php" class="brand">📒 NoteShare</a>
        <button class="burger" onclick="document.getElementById('menu').classList.toggle('buka')">☰</button>
    </header>

    <aside id="menu">
        <a href="profil.php">👤 Profil</a>
        <a href="catatan_saya.php">📄 Catatan</a>
        <a href="upload.php">⬆ Upload</a>
        <a href="logout.php">⎋ Log out</a>
    </aside>
<?php endif; ?>

<main>
