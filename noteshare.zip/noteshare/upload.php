<?php
include 'koneksi.php';
cek_login();

$err = '';
$ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul']);
    $mk = trim($_POST['mata_kuliah']);
    $status = ($_POST['status'] ?? '') === 'draft' ? 'draft' : 'publish';

    $f = $_FILES['file'] ?? null;
    $ext = $f ? strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) : '';

    if ($judul === '' || $mk === '' || !$f || $f['error'] !== 0) {
        $err = "Judul, mata kuliah, dan file wajib diisi.";
    } elseif (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'ppt', 'pptx'])) {
        $err = "Format file tidak diizinkan.";
    } elseif ($f['size'] > 10 * 1024 * 1024) {
        $err = "Ukuran file maksimal 10 MB.";
    } else {
        $nf = uniqid('n_') . ".$ext";
        move_uploaded_file($f['tmp_name'], "uploads/$nf");

        $st = $db->prepare(
            "INSERT INTO catatan(user_id,judul,mata_kuliah,angkatan,tag,deskripsi,file,status)
             VALUES(?,?,?,?,?,?,?,?)"
        );
        $st->bind_param(
            "isssssss",
            $_SESSION['uid'],
            $judul,
            $mk,
            $_POST['angkatan'],
            $_POST['tag'],
            $_POST['deskripsi'],
            $nf,
            $status
        );
        $st->execute();

        $ok = $status == 'draft' ? "Disimpan sebagai draft." : "Catatan berhasil dipublikasikan.";
    }
}

include 'header.php';
?>

<h2>Upload Catatan</h2>

<?php if ($err): ?>
    <div class="alert"><?= e($err) ?></div>
<?php endif; ?>

<?php if ($ok): ?>
    <div class="alert ok"><?= e($ok) ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="box">
    <label>Judul</label>
    <input name="judul" required>

    <label>Mata kuliah</label>
    <input name="mata_kuliah" required>

    <label>Angkatan</label>
    <input name="angkatan" placeholder="contoh: 2025">

    <label>Tag (pisahkan koma)</label>
    <input name="tag" placeholder="php, web, sql">

    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="4"></textarea>

    <label>File (pdf, gambar, doc, ppt; maks 10 MB)</label>
    <input type="file" name="file" required>

    <button name="status" value="publish">Publish</button>
    <button name="status" value="draft" class="btn alt">Simpan Draft</button>
</form>

<?php include 'footer.php'; ?>
