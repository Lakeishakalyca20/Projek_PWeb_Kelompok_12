<?php
include 'koneksi.php';
cek_login();

$id = (int)($_GET['id'] ?? 0);
$u = $_SESSION['uid'];

$st = $db->prepare("DELETE FROM bookmark WHERE user_id=? AND catatan_id=?");
$st->bind_param("ii", $u, $id);
$st->execute();

if ($st->affected_rows == 0) {
    $st = $db->prepare("INSERT IGNORE INTO bookmark(user_id,catatan_id) VALUES(?,?)");
    $st->bind_param("ii", $u, $id);
    $st->execute();
}

$k = basename($_GET['kembali'] ?? '');
header("Location: " . ($k ?: 'index.php'));
