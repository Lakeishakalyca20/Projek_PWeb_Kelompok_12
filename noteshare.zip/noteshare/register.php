<?php
include 'koneksi.php';

$tanpa_menu = 1;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);

    if ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = "Nama dan email harus valid.";
    } elseif (strlen($_POST['password']) < 6) {
        $err = "Password minimal 6 karakter.";
    } elseif ($_POST['password'] !== $_POST['konfirmasi']) {
        $err = "Konfirmasi password tidak sama.";
    } else {
        $h = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $st = $db->prepare("INSERT INTO users(nama,email,password) VALUES(?,?,?)");
        $st->bind_param("sss", $nama, $email, $h);

        if ($st->execute()) {
            header("Location: login.php?daftar=1");
            exit;
        }

        $err = "Email sudah terdaftar.";
    }
}

include 'header.php';
?>

<div class="auth">
    <div style="font-size:48px">📒</div>
    <h2>Daftar NoteShare</h2>

    <div class="box">
        <?php if ($err): ?>
            <div class="alert"><?= e($err) ?></div>
        <?php endif; ?>

        <form method="post">
            <input name="nama" placeholder="Nama" required>
            <br><br>
            <input type="email" name="email" placeholder="Email" required>
            <br><br>
            <input type="password" name="password" placeholder="Password" required>
            <br><br>
            <input type="password" name="konfirmasi" placeholder="Konfirmasi password" required>
            <button>Daftar</button>
        </form>
    </div>

    <p>Sudah punya akun? <a href="login.php">Login</a></p>
</div>

<?php include 'footer.php'; ?>
