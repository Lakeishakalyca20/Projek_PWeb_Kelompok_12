<?php
function kartu($r, $db)
{
    $ext = strtolower(pathinfo($r['file'], PATHINFO_EXTENSION));

    if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
        $thumb = "<img src='uploads/" . e($r['file']) . "' alt=''>";
    } else {
        $thumb = "<div class='ext'>" . strtoupper($ext) . "</div>";
    }

    $fav = '♡';

    if (isset($_SESSION['uid'])) {
        $st = $db->prepare("SELECT 1 FROM bookmark WHERE user_id=? AND catatan_id=?");
        $st->bind_param("ii", $_SESSION['uid'], $r['id']);
        $st->execute();

        if ($st->get_result()->num_rows) {
            $fav = '♥';
        }
    }

    $back = urlencode(basename($_SERVER['REQUEST_URI']));

    echo "<div class='kartu'>
        <a href='catatan.php?id=$r[id]'>$thumb<h4>" . e($r['judul']) . "</h4></a>
        <div class='meta'>
            <a href='profil.php?id=$r[user_id]'>" . e($r['nama']) . "</a>
            · ★ " . number_format($r['rata'], 1) . " ($r[jml])
        </div>
        <a class='love' href='bookmark.php?id=$r[id]&kembali=$back'>$fav</a>
    </div>";
}
