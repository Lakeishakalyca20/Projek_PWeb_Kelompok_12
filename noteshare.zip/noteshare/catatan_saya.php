<?php
include 'koneksi.php';
cek_login();
include 'kartu.php';

$uid = $_SESSION['uid'];
$tab = in_array($_GET['tab'] ?? '', ['draft', 'bookmark']) ? $_GET['tab'] : 'upload';

$w = [
    "upload"   => "c.user_id=? AND c.status='publish'",
    "draft"    => "c.user_id=? AND c.status='draft'",
    "bookmark" => "c.status='publish' AND c.id IN (SELECT catatan_id FROM bookmark WHERE user_id=?)",
];

$data = ambil_catatan($db, $w[$tab], "c.created_at DESC", 50, "i", [$uid]);

include 'header.php';
?>

<h2>Catatan</h2>

<div class="tabs">
    <?php foreach (['upload', 'draft', 'bookmark'] as $t): ?>
        <a href="?tab=<?= $t ?>" class="<?= $t == $tab ? 'on' : '' ?>"><?= ucfirst($t) ?></a>
    <?php endforeach; ?>
</div>

<div class="box">
    <div class="grid">
        <?php while ($r = $data->fetch_assoc()): ?>
            <?php kartu($r, $db); ?>
        <?php endwhile; ?>
    </div>

    <?php if ($data->num_rows == 0): ?>
        <p>Belum ada catatan di sini.</p>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
